Lemo 美术风格约束 / Blender 4.3
Install from Disk this ZIP and enable Lemo 美术风格约束.
3D View > N sidebar > Lemo 风格.
Choose a style and load its art rules. No scene objects are generated.
The eight rule sets are translated/adapted from the pinned Lemo STYLE documents.
The source quotes, source commit, and palette provenance are recorded per rule.
Colour swatches are references only, never a completed material setup.
The original docs and their adaptations retain CC BY-NC 4.0 and the upstream
additional permission for making your own films, including commercial/client films.
See licenses/LICENSE for the complete original terms.
Source: https://github.com/lemomo-ai/lemo-opuscar
Pinned: 00a7f9ec99c8686265a8ca4ed9a3fdaaf27ea6f4
Original author: Lemomo (LemoLab).
The Blender loader is independently adapted code under MIT, not upstream Blender code.
See LICENSE, NOTICE.md and LICENSES/MIT.txt for this package; source terms remain
in licenses/LICENSE. Rule JSON and translated cards remain CC BY-NC 4.0.
